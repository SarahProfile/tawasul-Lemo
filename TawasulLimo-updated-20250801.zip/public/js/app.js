// Console log for Google Maps API loading
console.log('Loading Google Maps API...');

// Global variables for Google Maps
let map;
let marker;
let currentLocationType = null;
let selectedLocation = null;

// Enhanced scroll detection for sticky header
let lastScrollTop = 0;
const header = document.querySelector('header');

window.addEventListener('scroll', function() {
    let scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    
    // Add scrolled class for enhanced backdrop effect
    if (scrollTop > 50) {
        header.classList.add('scrolled');
    } else {
        header.classList.remove('scrolled');
    }
    
    lastScrollTop = scrollTop;
});

// Mobile menu functionality
function toggleMobileMenu() {
    const mobileMenu = document.getElementById('mobileMenu');
    const overlay = document.querySelector('.mobile-menu-overlay');
    
    mobileMenu.classList.toggle('active');
    overlay.classList.toggle('active');
    
    // Prevent body scroll when menu is open
    if (mobileMenu.classList.contains('active')) {
        document.body.style.overflow = 'hidden';
    } else {
        document.body.style.overflow = '';
    }
}

function closeMobileMenu() {
    const mobileMenu = document.getElementById('mobileMenu');
    const overlay = document.querySelector('.mobile-menu-overlay');
    
    mobileMenu.classList.remove('active');
    overlay.classList.remove('active');
    document.body.style.overflow = '';
}

function closeMapModal() {
    const modal = document.getElementById('mapModal');
    if (modal) {
        modal.style.display = 'none';
    }
    selectedLocation = null;
}

function confirmLocation() {
    if (selectedLocation && currentLocationType) {
        const inputField = document.getElementById(currentLocationType === 'pickup' ? 'pickup' : 'dropoff');
        const latField = document.getElementById(currentLocationType + '_lat');
        const lngField = document.getElementById(currentLocationType + '_lng');
        
        inputField.value = selectedLocation.address;
        latField.value = selectedLocation.lat;
        lngField.value = selectedLocation.lng;
        
        closeMapModal();
    } else {
        alert('Please select a location on the map first.');
    }
}

// Booking form submission
document.addEventListener('DOMContentLoaded', function() {
    const bookingForm = document.getElementById('bookingForm');
    if (bookingForm) {
        bookingForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const submitBtn = document.getElementById('submitBookingBtn');
            const originalText = submitBtn.textContent;
            
            // Disable button and show loading
            submitBtn.disabled = true;
            submitBtn.textContent = 'Submitting...';
            
            const formData = new FormData(this);
            
            // Add CSRF token
            formData.append('_token', document.querySelector('meta[name="csrf-token"]').getAttribute('content'));
            
            // Note: This fetch URL will need to be dynamically set in the blade template
            fetch('/booking', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    this.reset(); // Reset form
                    // Clear hidden fields and location inputs
                    document.getElementById('pickup').value = '';
                    document.getElementById('dropoff').value = '';
                    document.getElementById('pickup_lat').value = '';
                    document.getElementById('pickup_lng').value = '';
                    document.getElementById('dropoff_lat').value = '';
                    document.getElementById('dropoff_lng').value = '';
                } else {
                    alert('Error: ' + (data.message || 'Please check your information and try again.'));
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            })
            .finally(() => {
                // Re-enable button
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            });
        });
    }
});

function subscribeNewsletter() {
    const email = document.querySelector('.newsletter-input input[type="email"]').value;
    if (email) {
        alert('Thank you for subscribing! We will keep you updated.');
        document.querySelector('.newsletter-input input[type="email"]').value = '';
    } else {
        alert('Please enter a valid email address');
    }
}

// New functions for Section 4
function applyNow() {
    // Scroll to the hero section to show the booking form from the top
    const heroSection = document.getElementById('home');
    if (heroSection) {
        heroSection.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    } else {
        // Fallback: scroll to booking form if hero section not found
        const bookingForm = document.getElementById('bookingForm');
        if (bookingForm) {
            bookingForm.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    }
}

function downloadApps() {
    alert('Our mobile app will be available soon! We will notify you.');
}

// FAQ Toggle Functionality
function toggleFAQ(element) {
    const faqItem = element.parentElement;
    const icon = element.querySelector('.faq-icon');
    
    // Close all other FAQ items
    const allFaqItems = document.querySelectorAll('.faq-item');
    allFaqItems.forEach(item => {
        if (item !== faqItem) {
            item.classList.remove('active');
            const otherIcon = item.querySelector('.faq-icon');
            otherIcon.textContent = '+';
        }
    });
    
    // Toggle current FAQ item
    faqItem.classList.toggle('active');
    
    if (faqItem.classList.contains('active')) {
        icon.textContent = '×';
    } else {
        icon.textContent = '+';
    }
}

// Close mobile menu when clicking outside
document.addEventListener('click', function(event) {
    const mobileMenu = document.getElementById('mobileMenu');
    const toggle = document.querySelector('.mobile-menu-toggle');
    
    if (mobileMenu && toggle && !mobileMenu.contains(event.target) && !toggle.contains(event.target)) {
        closeMobileMenu();
    }
});

// Handle window resize
window.addEventListener('resize', function() {
    if (window.innerWidth > 768) {
        closeMobileMenu();
    }
});

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Populate date dropdown with next 30 days
function populateDateDropdown() {
    const dateSelect = document.getElementById('date');
    if (!dateSelect) return;
    
    const today = new Date();
    
    for (let i = 0; i < 30; i++) {
        const date = new Date(today);
        date.setDate(today.getDate() + i);
        
        const option = document.createElement('option');
        const dateString = date.toISOString().split('T')[0];
        const displayDate = date.toLocaleDateString('en-US', { 
            weekday: 'short', 
            month: 'short', 
            day: 'numeric',
            year: 'numeric'
        });
        
        option.value = dateString;
        option.textContent = displayDate;
        dateSelect.appendChild(option);
    }
}

// Initialize Google Maps (with fallback)
window.initMap = function() {
    console.log('initMap called');
    try {
        const mapElement = document.getElementById('map');
        console.log('Map element found:', mapElement);
        
        if (!mapElement) {
            console.error('Map container element not found!');
            return;
        }
        
        // Default location: Dubai
        const defaultLocation = { lat: 25.2048, lng: 55.2708 };
        console.log('Creating map with default location:', defaultLocation);
        
        map = new google.maps.Map(mapElement, {
            zoom: 13,
            center: defaultLocation,
        });
        
        console.log('Map created successfully:', map);

        marker = new google.maps.Marker({
            position: defaultLocation,
            map: map,
            draggable: true
        });

        // Add click listener to map
        map.addListener('click', function(event) {
            const clickedLocation = {
                lat: event.latLng.lat(),
                lng: event.latLng.lng()
            };
            
            marker.setPosition(clickedLocation);
            
            // Get address from coordinates
            const geocoder = new google.maps.Geocoder();
            geocoder.geocode({ location: clickedLocation }, function(results, status) {
                if (status === 'OK' && results[0]) {
                    selectedLocation = {
                        address: results[0].formatted_address,
                        lat: clickedLocation.lat,
                        lng: clickedLocation.lng
                    };
                }
            });
        });

        // Add drag listener to marker
        marker.addListener('dragend', function() {
            const position = marker.getPosition();
            const location = {
                lat: position.lat(),
                lng: position.lng()
            };
            
            // Get address from coordinates
            const geocoder = new google.maps.Geocoder();
            geocoder.geocode({ location: location }, function(results, status) {
                if (status === 'OK' && results[0]) {
                    selectedLocation = {
                        address: results[0].formatted_address,
                        lat: location.lat,
                        lng: location.lng
                    };
                }
            });
        });

        // Initialize Places Autocomplete
        const input = document.createElement('input');
        input.type = 'text';
        input.placeholder = 'Search for a location...';
        input.style.cssText = 'margin: 10px; padding: 10px; width: calc(100% - 40px); border: 1px solid #ccc; border-radius: 5px;';
        
        const autocomplete = new google.maps.places.Autocomplete(input);
        autocomplete.bindTo('bounds', map);

        map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

        autocomplete.addListener('place_changed', function() {
            const place = autocomplete.getPlace();
            if (place.geometry) {
                map.setCenter(place.geometry.location);
                map.setZoom(15);
                marker.setPosition(place.geometry.location);
                
                selectedLocation = {
                    address: place.formatted_address,
                    lat: place.geometry.location.lat(),
                    lng: place.geometry.location.lng()
                };
            }
        });

        // Initialize Places Autocomplete for the search input
        const searchInput = document.getElementById('mapSearch');
        if (searchInput) {
            const autocomplete = new google.maps.places.Autocomplete(searchInput, {
                types: ['establishment', 'geocode'],
                componentRestrictions: { country: 'ae' } // Restrict to UAE
            });

            autocomplete.addListener('place_changed', function() {
                const place = autocomplete.getPlace();
                if (place.geometry) {
                    const location = {
                        lat: place.geometry.location.lat(),
                        lng: place.geometry.location.lng()
                    };
                    
                    // Center map on the selected place
                    map.setCenter(location);
                    map.setZoom(16);
                    
                    // Move marker to the selected place
                    marker.setPosition(location);
                    
                    // Update selected location
                    selectedLocation = {
                        address: place.formatted_address || place.name,
                        lat: location.lat,
                        lng: location.lng
                    };
                }
            });
        }
    } catch (error) {
        console.log('Google Maps API not available. Using fallback location input.');
        // If Google Maps fails, convert location inputs to text inputs
        const pickupInput = document.getElementById('pickup');
        const dropoffInput = document.getElementById('dropoff');
        
        if (pickupInput) {
            pickupInput.removeAttribute('readonly');
            pickupInput.removeAttribute('onclick');
            pickupInput.placeholder = 'Enter pickup address manually';
        }
        
        if (dropoffInput) {
            dropoffInput.removeAttribute('readonly');
            dropoffInput.removeAttribute('onclick');
            dropoffInput.placeholder = 'Enter drop-off address manually';
        }
    }
}

// Handle location input - try map selector first, fallback to manual input
function handleLocationInput(type) {
    console.log('handleLocationInput called with type:', type);
    
    // Don't clear the current value - let the user see it in the map and decide
    // Try to open map selector
    try {
        openMapSelector(type);
    } catch (error) {
        console.error('Error opening map selector:', error);
        // Fallback to manual input
        const inputField = document.getElementById(type === 'pickup' ? 'pickup' : 'dropoff');
        if (inputField) {
            inputField.focus();
            inputField.placeholder = 'Type your address here';
            alert('Map selector not available. Please type the address manually.');
        }
    }
}

// Map selector functions with fallback
function openMapSelector(type) {
    console.log('openMapSelector called with type:', type);
    
    const inputField = document.getElementById(type === 'pickup' ? 'pickup' : 'dropoff');
    
    // Check if Google Maps is available
    if (typeof google === 'undefined' || !google.maps) {
        console.log('Google Maps not available, enabling manual input');
        // Google Maps not available - allow manual input
        if (inputField) {
            inputField.removeAttribute('onclick');
            inputField.focus();
            // Show a one-time message about manual input
            if (!inputField.hasAttribute('data-manual-mode')) {
                inputField.setAttribute('data-manual-mode', 'true');
                inputField.placeholder = 'Type your address here';
                alert('Map selector not available. Please type the address manually.');
            }
        }
        return;
    }
    
    console.log('Google Maps available, opening modal');
    currentLocationType = type;
    const modal = document.getElementById('mapModal');
    const title = document.getElementById('mapModalTitle');
    
    if (!modal) {
        console.error('Map modal not found!');
        // Fallback to manual input
        if (inputField) {
            inputField.focus();
            alert('Map interface not available. Please type the address manually.');
        }
        return;
    }
    
    if (modal && title) {
        title.textContent = type === 'pickup' ? 'Select Pickup Location' : 'Select Drop-off Location';
        modal.style.display = 'block';
        
        // Reinitialize map when modal opens
        setTimeout(() => {
            if (map) {
                google.maps.event.trigger(map, 'resize');
                console.log('Map resized');
                
                // Check if there's already a location set for this input
                const inputField = document.getElementById(type === 'pickup' ? 'pickup' : 'dropoff');
                const latField = document.getElementById(type + '_lat');
                const lngField = document.getElementById(type + '_lng');
                
                if (latField && lngField && latField.value && lngField.value) {
                    // Show existing location on map
                    const existingLocation = {
                        lat: parseFloat(latField.value),
                        lng: parseFloat(lngField.value)
                    };
                    map.setCenter(existingLocation);
                    marker.setPosition(existingLocation);
                    selectedLocation = {
                        address: inputField.value,
                        lat: existingLocation.lat,
                        lng: existingLocation.lng
                    };
                } else if (type === 'pickup' && navigator.geolocation) {
                    // Try to get current location for pickup if no location is set
                    navigator.geolocation.getCurrentPosition(function(position) {
                        const userLocation = {
                            lat: position.coords.latitude,
                            lng: position.coords.longitude
                        };
                        map.setCenter(userLocation);
                        marker.setPosition(userLocation);
                        
                        // Get address from coordinates
                        const geocoder = new google.maps.Geocoder();
                        geocoder.geocode({ location: userLocation }, function(results, status) {
                            if (status === 'OK' && results[0]) {
                                selectedLocation = {
                                    address: results[0].formatted_address,
                                    lat: userLocation.lat,
                                    lng: userLocation.lng
                                };
                            }
                        });
                    });
                }
            } else {
                console.error('Map not initialized!');
            }
        }, 100);
    }
}

// Use current location in map modal
function useCurrentLocationInMap() {
    const currentLocationBtn = document.getElementById('useCurrentLocationBtn');
    
    if (!navigator.geolocation) {
        alert('Geolocation is not supported by this browser.');
        return;
    }
    
    // Disable button and show loading
    currentLocationBtn.disabled = true;
    currentLocationBtn.textContent = '📍 Getting Location...';
    
    navigator.geolocation.getCurrentPosition(
        function(position) {
            const userLocation = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };
            
            if (map && marker) {
                map.setCenter(userLocation);
                marker.setPosition(userLocation);
                
                // Get address from coordinates
                const geocoder = new google.maps.Geocoder();
                geocoder.geocode({ location: userLocation }, function(results, status) {
                    if (status === 'OK' && results[0]) {
                        selectedLocation = {
                            address: results[0].formatted_address,
                            lat: userLocation.lat,
                            lng: userLocation.lng
                        };
                        
                        // Re-enable button
                        currentLocationBtn.disabled = false;
                        currentLocationBtn.textContent = '📍 Use Current Location';
                    } else {
                        console.error('Geocoding failed:', status);
                        selectedLocation = {
                            address: `Current Location (${userLocation.lat.toFixed(6)}, ${userLocation.lng.toFixed(6)})`,
                            lat: userLocation.lat,
                            lng: userLocation.lng
                        };
                        
                        // Re-enable button
                        currentLocationBtn.disabled = false;
                        currentLocationBtn.textContent = '📍 Use Current Location';
                    }
                });
            }
        },
        function(error) {
            console.error('Geolocation error:', error);
            alert('Unable to get your current location. Please try again or select manually.');
            
            // Re-enable button
            currentLocationBtn.disabled = false;
            currentLocationBtn.textContent = '📍 Use Current Location';
        },
        {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 300000 // 5 minutes
        }
    );
}

// Initialize date dropdown on page load
document.addEventListener('DOMContentLoaded', function() {
    populateDateDropdown();
    initializeDateTimeInputs();
    
    // Initialize current location after a short delay to ensure Google Maps is loaded
    setTimeout(() => {
        initializeCurrentLocation();
    }, 1000);
    
    // Fallback initialization for Google Maps if callback doesn't work
    setTimeout(() => {
        if (typeof google !== 'undefined' && google.maps && !map) {
            console.log('Initializing Google Maps via fallback');
            initMap();
        }
    }, 2000);
});

// Initialize current location for pickup field
function initializeCurrentLocation() {
    const pickupInput = document.getElementById('pickup');
    const pickupLatInput = document.getElementById('pickup_lat');
    const pickupLngInput = document.getElementById('pickup_lng');
    
    if (!pickupInput) return;
    
    // Check if geolocation is supported
    if (navigator.geolocation) {
        // Show loading state
        pickupInput.placeholder = 'Getting your current location...';
        
        navigator.geolocation.getCurrentPosition(
            function(position) {
                const userLocation = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                };
                
                // Use reverse geocoding to get the address
                if (typeof google !== 'undefined' && google.maps) {
                    const geocoder = new google.maps.Geocoder();
                    geocoder.geocode({ location: userLocation }, function(results, status) {
                        if (status === 'OK' && results[0]) {
                            pickupInput.value = results[0].formatted_address;
                            pickupLatInput.value = userLocation.lat;
                            pickupLngInput.value = userLocation.lng;
                            pickupInput.placeholder = 'Click to select on map or type address';
                        } else {
                            console.error('Geocoding failed:', status);
                            pickupInput.placeholder = 'Click to select on map or type address';
                        }
                    });
                } else {
                    // If Google Maps is not available, just store coordinates
                    pickupLatInput.value = userLocation.lat;
                    pickupLngInput.value = userLocation.lng;
                    pickupInput.value = `Current Location (${userLocation.lat.toFixed(6)}, ${userLocation.lng.toFixed(6)})`;
                    pickupInput.placeholder = 'Click to select on map or type address';
                }
            },
            function(error) {
                console.error('Geolocation error:', error);
                pickupInput.placeholder = 'Click to select on map or type address';
                
                // Handle different error cases
                switch(error.code) {
                    case error.PERMISSION_DENIED:
                        console.log('User denied the request for Geolocation.');
                        break;
                    case error.POSITION_UNAVAILABLE:
                        console.log('Location information is unavailable.');
                        break;
                    case error.TIMEOUT:
                        console.log('The request to get user location timed out.');
                        break;
                    default:
                        console.log('An unknown error occurred.');
                        break;
                }
            },
            {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 300000 // 5 minutes
            }
        );
    } else {
        console.log('Geolocation is not supported by this browser.');
        pickupInput.placeholder = 'Click to select on map or type address';
    }
}

// Initialize date and time inputs with better UX
function initializeDateTimeInputs() {
    const dateInput = document.getElementById('date');
    const timeInput = document.getElementById('time');
    
    // Set minimum date to today
    if (dateInput) {
        const today = new Date();
        const formattedDate = today.toISOString().split('T')[0];
        dateInput.setAttribute('min', formattedDate);
        
        // Set default to today if no value
        if (!dateInput.value) {
            dateInput.value = formattedDate;
        }
        
        // Add validation for past dates
        dateInput.addEventListener('change', function() {
            const selectedDate = new Date(this.value);
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            
            if (selectedDate < today) {
                alert('Please select a date from today onwards.');
                this.value = today.toISOString().split('T')[0];
            }
        });
    }
    
    // Set default time to current time + 1 hour
    if (timeInput && !timeInput.value) {
        const now = new Date();
        now.setHours(now.getHours() + 1);
        const hours = now.getHours().toString().padStart(2, '0');
        const minutes = now.getMinutes().toString().padStart(2, '0');
        timeInput.value = `${hours}:${minutes}`;
    }
}

// Google Maps is initialized via window.initMap callback